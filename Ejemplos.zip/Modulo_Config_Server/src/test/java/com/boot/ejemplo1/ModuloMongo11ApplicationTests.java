package com.boot.ejemplo1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModuloMongo11ApplicationTests {

	@Test
	void contextLoads() {
	}

}

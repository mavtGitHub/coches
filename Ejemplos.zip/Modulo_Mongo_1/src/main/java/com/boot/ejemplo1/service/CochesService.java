package com.boot.ejemplo1.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.ejemplo1.dao.ICochesDao;
import com.boot.ejemplo1.dto.Coche;
import com.boot.ejemplo1.model.CocheEntity;

@Service
public class CochesService implements ICochesService
{
	@Autowired ICochesDao icochesDao;
	
	@Override
	public List<Coche> getCoches() {
		
		insertCoche();
		
		System.out.println("Servicio getCoches start......");
		List<Coche> result=new ArrayList<Coche>();
		icochesDao.getCoches();
		for(CocheEntity cocheEntity:icochesDao.getCoches()) 
		{
			Coche item=new Coche(cocheEntity.getModelo(),cocheEntity.getMatricula());
			
			result.add(item);
			
		}
		System.out.println("Servicio getCoches end......");
		return result;
		
		
	}
	
	
	public Coche insertCoche() {
		
		System.out.println("Servicio Coches start......");
		
		// vamos a insertar en la coleccion de coches, coches
		Coche test=new Coche("FORD MUSTANGGG","8807HCSSS");
		
		System.out.println("Insertando coche......");
		
		
		CocheEntity entidad=new CocheEntity(test.getModelo(), test.getMatricula());
		
		icochesDao.insertarCoche(entidad);
		System.out.println("Insertado coche......");
		return test;
		
		
	}
	
	
	

	
	
}

package com.boot.ejemplo1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.ejemplo1.dto.Coche;
import com.boot.ejemplo1.service.ICochesService;

@RestController
public class EjemploGetController 
{
	@Autowired ICochesService iCochesService;
	
	@GetMapping(value = "getCoches")
	public List<Coche> getCoches() 
	{
		return iCochesService.getCoches();
	}
	
	
	
	
	
	
}

package com.boot.ejemplo1.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "coches")
public class CocheEntity {

	@Id
	private String modelo;
	private String matricula;
	public String getModelo() {
		return modelo;
	}
	
	
	
	
	
	
	public CocheEntity(String modelo, String matricula) {
		super();
		this.modelo = modelo;
		this.matricula = matricula;
	}






	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	
	
	
	
	
	
}

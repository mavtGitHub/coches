package com.boot.ejemplo1.dao;


import java.util.List;

import com.boot.ejemplo1.model.CocheEntity;

public interface ICochesDao 
{
	public void insertarCoche(CocheEntity coche);
	
	public List<CocheEntity> getCoches();
	
}

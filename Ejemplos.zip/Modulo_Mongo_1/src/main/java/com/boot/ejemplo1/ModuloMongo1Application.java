package com.boot.ejemplo1;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;

@SpringBootApplication
@EnableMongoRepositories(basePackages = "com.boot.ejemplo1.repository")
@EnableConfigurationProperties
public class ModuloMongo1Application 
{
	@Value("${spring.data.mongodb.port}")
	String puerto;
	
	@Value("${spring.data.mongodb.database}")
	String dataBase;
	
	
	public static void main(String[] args) {
		SpringApplication.run(ModuloMongo1Application.class, args);
	}
	
	
	
	@Bean
    public MongoClient mongo() {
		System.out.println("Mongo .........."+puerto);
        ConnectionString connectionString = new ConnectionString("mongodb://localhost:"+puerto);
        MongoClientSettings mongoClientSettings = MongoClientSettings.builder()
          .applyConnectionString(connectionString)
          .build();
        
        return MongoClients.create(mongoClientSettings);
    }

    @Bean
    public MongoTemplate mongoTemplate() throws Exception {
    	System.out.println("Mongo template.............."+dataBase);
        return new MongoTemplate(mongo(), dataBase);
    }
	
	
	

}

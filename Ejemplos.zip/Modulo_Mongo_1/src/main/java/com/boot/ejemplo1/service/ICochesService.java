package com.boot.ejemplo1.service;

import java.util.List;

import com.boot.ejemplo1.dto.Coche;

public interface ICochesService {
	
	public List<Coche> getCoches();

}

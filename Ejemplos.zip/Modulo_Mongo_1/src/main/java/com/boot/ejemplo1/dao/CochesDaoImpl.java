package com.boot.ejemplo1.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.boot.ejemplo1.model.CocheEntity;
import com.boot.ejemplo1.repository.CochesRepository;

@Repository
public class CochesDaoImpl implements ICochesDao
{
	@Autowired CochesRepository cochesRepository;
	
	
	@Override
	public void insertarCoche(CocheEntity coche) {
		cochesRepository.save(coche);
	}


	@Override
	public List<CocheEntity> getCoches() {
		return cochesRepository.findAll();
	}

}

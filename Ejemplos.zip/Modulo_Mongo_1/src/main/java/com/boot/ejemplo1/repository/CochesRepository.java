package com.boot.ejemplo1.repository;

import org.springframework.data.mongodb.repository.MongoRepository;


import com.boot.ejemplo1.model.CocheEntity;

public interface CochesRepository extends MongoRepository<CocheEntity, String> 
{
	
}
